import java.util.*;

/*
 * A BinaryTree class with an inner BinaryNode class. Contains lots of practice 
 * with recursive methods.
 * Many (but not all) of the methods in this class will require additional
 * recursive helper methods. The helper method would typically
 * have a BinaryNode as its parameter.
 * 
 * _______________ YOUR NAME HERE
 */

public class BinaryTree {

	private BinaryNode root;

	// constructs an empty binary tree
	public BinaryTree() {
		root = null;
	}

	/*
	 * Returns a count of the number of nodes in the tree see video, part1
	 * ***** SOLVED IN FIRST VIDEO *****
	 */
	public int nodeCount() {
	    return nodeCount(root);
	}
	
	// Helper recursive method
	private int nodeCount(BinaryNode top) {
	    if (top == null) {
            return 0;
        }
        
        int count = 1;
        // Doesn't have if null since the tree class won't throw exception if
        // left/right is null
        count += nodeCount(top.left);
        count += nodeCount(top.right);
        
        return count;
	}
	
	/*
	 * Returns the sum of the data in the nodes
	 */
	public int sum() {
	    
	    return sum(root);
	}
	
	// Helper recursive method
	private int sum(BinaryNode top) {
	    int res = 0;
	    // Base case
	    if (top == null) {
	        return 0;
	    }
	    
	    res += top.data;
	    
	    // Recursive calls to top's subnodes
	    res += sum(top.left);
	    res += sum(top.right);
	    
	    return res;
	}
	

	/*
	 * Returns max value in the tree See video, part1
	 * ***** SOLVED IN FIRST VIDEO *****
	 */
	public int max() {
		if (root == null) {
			throw new IllegalStateException("Tree is empty");
		} 
		
		return max(root, root.data);
	}
	
	// Helper recursive method. currMax will keep track of the current max
	private int max(BinaryNode top, int currMax) {
	    // Base case
	    if (top == null) {
	        return currMax;
	    }
	    
	    // Set top data to max if it's greater
	    if (top.data > currMax) {
	        currMax = top.data;
	    }
	    
	    // Recursive calls for the subnodes
	    currMax = max(top.left, currMax);
	    currMax = max(top.right, currMax);
	    
	    return currMax;
	}

	/*
	 * returns the number of leaves in a tree
	 * ***** SOLVED IN SECOND VIDEO *****
	 */
	public int leafCount() {
		return leafCount(root);
	}
	
	// Helper recursive method
	private int leafCount(BinaryNode top) {
	    int count = 0;
	    // Base case
	    if (top == null) {
	        return count;
	    }
	    
	    // If it's a leaf, 1 is added
	    if (top.left == null && top.right == null) {
	        return 1;
	    }
	    
	    // Recursive calls to top's subnodes
	    count += leafCount(top.left);
	    count += leafCount(top.right);
	    
	    return count;
	}

	/*
	 * Returns a set of all leaf values.
	 * ***** SOLVED IN SECOND VIDEO *****
	 */
	public Set<Integer> allLeaves() {
	    Set<Integer> result = new TreeSet<Integer>();
	    
		allLeaves(root, result);
		return result;
	}
	
	// Helper recursive method
	private void allLeaves(BinaryNode top, Set<Integer> currSet) {
	    if (top == null) {
	        return;
	    }
	    
	    // If it's a leaf, it's added
	    if (top.left == null && top.right == null) {
	        currSet.add(top.data);
	        return;
	    }
	    
	    // Recursive calls for the subnodes
	    allLeaves(top.left, currSet);
	    allLeaves(top.right, currSet);
	    
	    // return currSet;
	}
	
	/*
	 * Returns a set of all sums that can be obtained by starting at the root and
	 * traveling to each leaf
	 * ***** SOLVED IN SECOND VIDEO *****
	 */
	public Set<Integer> allSums() {
	    Set<Integer> result = new TreeSet<>();
	    
	    allSums(root, result, 0);  // Calls method to add different sums
	    
		return result;
	}
	
	// Helper recursive method
	private void allSums(BinaryNode top, Set<Integer> currSet, int currSum) {
	    // Base case
	    if (top == null) {
	        return;
	    }
	    
	    currSum += top.data;
	    
	    // adds the current sum to the set since a leaf was reached
	    if (top.left == null && top.right == null) {
	        currSet.add(currSum);
	    }
	    
	    
	    // Recursive calls
	    allSums(top.left, currSet, currSum);
	    
        allSums(top.right, currSet, currSum);
        
	}

	/*
	 * Returns a set of all possible paths from the root to the leaves. Similar
	 * to allSums, but rather than computing sums along the way, builds a string
	 * along the way, space-separated. 
	 * Trim the strings that get added to the sets. So, for example, in this tree:
	 *         5
	 *        / \
	 *       /   \
	 *      10   20
	 *     /  \    \
	 *    30  40   50
	 *  
	 *  allPaths() would return this set (order might be different):
	 *   {"5 10 30", "5 10 40", "5 20 50"}
	 *  TIP: allPaths() is a lot like allSums(). The difference
	 *  is that allSums is adding numbers to a total, and this
	 *  is adding numbers to a string.
	 */
	public Set<String> allPaths() {
	    Set<String> result = new TreeSet<>();
	    
	    allPaths(root, result, "");
	    
		return result;
	}
	
	// Helper recursive method
	private void allPaths(BinaryNode top, Set<String> currSet, String currPath) {
	    // Base case
	    if (top == null) {
	        return;
	    }
	    
	    currPath += "" + top.data + " ";  // Adds current node to the path
	    
	    // If top is a leaf, the path is added to the set.
	    if (top.left == null && top.right == null) {
	        currSet.add(currPath.trim());
	    } else {  // Otherwise, recursive calls are made to build the paths
	        allPaths(top.left, currSet, currPath);
	        allPaths(top.right, currSet, currPath);
	    }
	    
	    
	}
	
	/*
	 * Returns a set of all possible sums that can be obtained
	 * in the tree by starting at the root and traveling any path.
	 * This is similar to allSums() (in fact, it will include all the sums
	 * that are returned by allSums(), but it also includes all sums that can
	 * be obtained by stopping part-way.  So, for example, in this tree:
	 *         5
	 *        / \
	 *       /   \
	 *      10   20
	 *     /  \    \
	 *    30  40   50
	 *  
	 *  allSumsIncludingPartial() would return {5, 15, 25, 45, 55, 75}
	 *  whereas allSums() would only return {45, 55, 75}
	 */
	public Set<Integer> allSumsIncludingPartial() {
	    Set<Integer> result = new TreeSet<>();
	    
	    allSumsIncludingPartial(root, result, 0);
	    
		return result;
	}
	
	// Helper recursive method
	private void allSumsIncludingPartial(BinaryNode top, Set<Integer> currSet, int currSum) {
	    // Base case
	    if (top == null) {
	        return;
	    }
	    
	    // Adding the node, and putting it in the set.
	    // Doing this Since partials are allowed
	    currSum += top.data;
	    currSet.add(currSum);
	    
	    // Recursive calls
	    allSumsIncludingPartial(top.left, currSet, currSum);
	    allSumsIncludingPartial(top.right, currSet, currSum);
	}
	
	/*
	 * Returns the sum obtained using a "greedy algorithm" by starting at the root
	 * and going left or right depending on which node has
	 * the larger value (in case of a tie, go left). 
	 * If the tree is empty, throw an IllegalStateException();
	 * 
	 * So, for example, in this tree:
	 *         5
	 *        / \
	 *       /   \
	 *      10   20
	 *     / \   / \
	 *    30 90 70 50
	 *  
	 *  greedySum() would return 95 (5 + 20 + 70). Notice that greedySum() is not
	 *  necessarily the same as maxSum()
	 */
	public int greedySum() {
		if (root == null)
			throw new IllegalStateException("Empty tree");
		
		return greedySum(root, 0);
	}
	
	// Helper recursive method
	private int greedySum(BinaryNode top, int currSum) {
	    int sum = top.data;
	    
	    
	    
	    if (top.left != null) {
	        if (top.right != null) {
	            
	            if (top.left.data >= top.right.data) {
	                
	                sum += greedySum(top.left, sum);
	                
	            } else {
	                sum += greedySum(top.right, sum);
	            }
	        } else {
	            sum += greedySum(top.left, sum);
	        }
	    } else if (top.right != null) {
	        sum += greedySum(top.right, sum);
	    }
	    
	    return sum;
	}

	/*
	 * Returns the largest possible sum that can be obtained by starting at the root
	 * and traveling to a leaf. If the tree is empty, throw an
	 * IllegalStateException();
	 */
	public int maxSum() {
	    
		if (root == null)
			throw new IllegalStateException("Empty tree");
		
		
		return maxSum(root, root.data);
	}
	
	// Private recursor method
	private int maxSum(BinaryNode top, int currSum) {
	    
	    // Tracks maxes for both to return later
	    int maxLeft = currSum;
	    int maxRight = currSum;
	    
	    // Will recursively call left node until leaf is reached
	    if (top.left != null) {
	        // Travels left urecursively adding to the left sum
	        maxLeft += maxSum(top.left, top.left.data);
	    }
	    
	    
	    if (top.right != null) {
	        // Travels to right node recursively
	        maxRight += maxSum(top.right, top.right.data);
	    }
	    
	    return Math.max(maxLeft, maxRight);
	}

	// Postorder traversal that prints the nodes as they are visited
	// ***** SOLVED IN FIRST VIDEO *****
	public void postOrderTraversal() {
		postOrderTraversal(root);
		System.out.println();
	}
	
	// Recursive helper methods prints subnodes before printing top node
	private void postOrderTraversal(BinaryNode top) {
	    if (top == null) {
            return;
        }
        postOrderTraversal(top.left);
        postOrderTraversal(top.right);
        
        System.out.print(top.data + " ");
	}
	
	// preorder traversal that prints the nodes as they are visited
	public void preOrderTraversal() {
	    preOrderTraversal(root);
        System.out.println();
	}	
	
	// Recursive helper methods prints top node before printing subnodes
	private void preOrderTraversal(BinaryNode top) {
        if (top == null) {
            return;
        }
        
        System.out.print(top.data + " ");
        
        preOrderTraversal(top.left);
        preOrderTraversal(top.right);
        
        
    }
	
	/*
	 * Returns a queue of all the node data in the tree, in the order that they
	 * would be visited in a pre-order traversal. Solve this one recursively,
	 * building the queue as you go (rather than printing the data).
	 */
	public Queue<Integer> preOrderTraversalPath() {
	    
	    Queue<Integer> result = new LinkedList<>();
	    preOrderTraversalPath(root, result);
	    
		return result;
	}

	// Recursive helper method
	private void preOrderTraversalPath(BinaryNode top, Queue<Integer> queue) {
	    // Base case
	    if (top == null) {
            return;
        }
	    
	    // Adds all the integers starting from the top node before doing 
	    // subnodes
	    queue.add(top.data);
	    
	    preOrderTraversalPath(top.left, queue);
        preOrderTraversalPath(top.right, queue);
	}
	
	/*
	 * Returns the queue of all the node data in the tree, in the order that they
	 * would be visited in a level-order traversal. Solve this one using a queue and
	 * a loop, rather than recursively.
	 */
	public Queue<Integer> levelOrderTraversalPath() {
	    Queue<Integer> result = new LinkedList<>();
        levelOrderTraversalPath(root, result);
	    
		return result;
	}
	
	// Helper method
	private void levelOrderTraversalPath(BinaryNode top, Queue<Integer> result) {
	    if (top == null) {
	        return;
	    }
	    
	    // Queue to store tree as the nodes are added to result queue
	    Queue<BinaryNode> queue = new LinkedList<>();
	    
	    queue.add(top); 
	    
	    // Adds nodes to the result queue
	    while (!queue.isEmpty()) {
	        BinaryNode temp = queue.remove();  // Temp node
	        
	        result.add(temp.data);  // Adding element to resulting queue
	        
	        if (temp.left != null) {
	            queue.add(temp.left);
	        }
	        
	        if (temp.right != null) {
                queue.add(temp.right);
            }
	    }
	}

	//// **** DON'T MODIFY THE METHODS BELOW ****
	// Adds a node to this tree
	// Find the first open spot in my tree and that
	// is where I will put num in a new node.
	public void add(int num) {
		BinaryNode temp = new BinaryNode(num);

		if (root == null) { // empty tree? make root the new node
			root = temp;
			return;
		}

		// move through the tree using level-order traversal until
		// I find an open spot for the new node
		Queue<BinaryNode> q = new LinkedList<>();
		q.add(root);

		while (!q.isEmpty()) {
			BinaryNode first = q.remove();
			// see if the left or right is null. If so, put
			// the new node in that location.
			if (first.left == null) { // add new node to left
				first.left = temp;
				return;
			} else { // left is occupied, so try the right:
				if (first.right == null) {
					first.right = temp;
					return;
				} else { // first has two children
					q.add(first.left);
					q.add(first.right);
				}
			}
		}
	} 

	// Adds the specified value to a random location in the tree
	public void addRandomLocation(int n) {
		BinaryNode temp = new BinaryNode(n);

		if (root == null) {
			root = temp;
			return;
		} else {
			BinaryNode parent = root;

			while (true) {
				// randomly look right or left until a null is found
				if (Math.random() < .5) {
					if (parent.left == null) {
						parent.left = temp;
						return;
					} else {
						parent = parent.left;
					}
				} else {
					if (parent.right == null) {
						parent.right = temp;
						return;
					} else {
						parent = parent.right;
					}
				}
			}

		}

	}

	class BinaryNode {
		int data;
		BinaryNode left, right;

		BinaryNode(int data) {
			this.data = data;
			this.left = null;
			this.right = null;
		}
	}
}