import static org.junit.Assert.*;

import java.util.Queue;
import java.util.Set;

import org.junit.Test;

public class BinaryTreeTester {

	@Test
	public void testNodeCount() {
		BinaryTree bt = new BinaryTree();
		assertEquals(0, bt.nodeCount());

		for (int i = 1; i <= 100; i++) {
			bt.addRandomLocation(i);
			assertEquals(i, bt.nodeCount());
		}
	}
	
	@Test
	public void testSum() {
		BinaryTree bt = new BinaryTree();
		assertEquals(0, bt.sum());
		int sum = 0;

		for (int i = 1; i <= 100; i++) {
			bt.addRandomLocation(i);
			sum += i;
			assertEquals(sum, bt.sum());
		}
	} 

	@Test
	public void testMax() {
		BinaryTree bt = new BinaryTree();

		for (int i = 1; i <= 100; i++) {
			bt.addRandomLocation(i);
			assertEquals(i, bt.max());
		}

		bt = new BinaryTree();

		for (int i = -1; i >= -100; i--) {
			bt.addRandomLocation(i);
			assertEquals(-1, bt.max());
		}
	}

	@Test
	public void testLeafCount() {
		BinaryTree bt = new BinaryTree();
		assertEquals(0, bt.leafCount());

		for (int i = 1; i <= 100; i++) {
			bt.add(i);
			assertEquals("" + i, (i + 1) / 2, bt.leafCount());
		}

	}

	@Test
	public void testAllLeaves() {
		BinaryTree bt = new BinaryTree();
		assertEquals(0, bt.allLeaves().size());

		bt.add(17);
		Set<Integer> leaves = bt.allLeaves();
		assertEquals(1, leaves.size());
		assertTrue(leaves.contains(17));

		bt.add(10);
		leaves = bt.allLeaves();
		assertEquals(1, leaves.size());
		assertTrue(leaves.contains(10));

		bt.add(3);
		leaves = bt.allLeaves();
		assertEquals(2, leaves.size());
		assertTrue(leaves.contains(10));
		assertTrue(leaves.contains(3));

		bt.add(4);
		leaves = bt.allLeaves();
		assertEquals(2, leaves.size());
		assertTrue(leaves.contains(3));
		assertTrue(leaves.contains(4));
	}

	@Test
	public void testAllSums() {
		BinaryTree bt = new BinaryTree();
		assertEquals(0, bt.allSums().size());

		bt.add(17);
		Set<Integer> sums = bt.allSums();
		assertEquals(1, sums.size());
		assertTrue(sums.contains(17));

		bt.add(10);
		sums = bt.allSums();
		assertEquals(1, sums.size());
		assertTrue(sums.contains(27));

		bt.add(3);
		sums = bt.allSums();
		assertEquals(2, sums.size());
		assertTrue(sums.contains(27));
		assertTrue(sums.contains(20));

		bt.add(4);
		sums = bt.allSums();
		assertEquals(2, sums.size());
		assertTrue(sums.contains(20));
		assertTrue(sums.contains(31));
	}

	@Test
	public void testAllPaths() {
		BinaryTree bt = new BinaryTree();
		assertEquals(0, bt.allPaths().size());

		bt.add(17);
		Set<String> paths = bt.allPaths();
		assertEquals(1, paths.size());
		assertTrue(paths.contains("17"));

		bt.add(10);
		paths = bt.allPaths();
		assertEquals(1, paths.size());
		assertTrue(paths.contains("17 10"));

		bt.add(3);
		paths = bt.allPaths();
		assertEquals(2, paths.size());
		assertTrue(paths.contains("17 10"));
		assertTrue(paths.contains("17 3"));

		bt.add(4);
		paths = bt.allPaths();
		assertEquals(2, paths.size());
		assertTrue(paths.contains("17 10 4"));
		assertTrue(paths.contains("17 3"));
	}

	@Test
	public void testAllSumsIncludingPartial() {
		BinaryTree bt = new BinaryTree();
		assertEquals(0, bt.allSumsIncludingPartial().size());

		bt.add(17);
		Set<Integer> sums = bt.allSumsIncludingPartial();
		assertEquals(1, sums.size());
		assertTrue(sums.contains(17));

		bt.add(10);
		sums = bt.allSumsIncludingPartial();
		assertEquals(2, sums.size());
		assertTrue(sums.contains(17));
		assertTrue(sums.contains(27));

		bt.add(3);
		sums = bt.allSumsIncludingPartial();
		assertEquals(3, sums.size());
		assertTrue(sums.contains(17));
		assertTrue(sums.contains(27));
		assertTrue(sums.contains(20));

		bt.add(4);
		sums = bt.allSumsIncludingPartial();
		assertEquals(4, sums.size());
		assertTrue(sums.contains(17));
		assertTrue(sums.contains(27));
		assertTrue(sums.contains(20));
		assertTrue(sums.contains(31));

	}

	@Test
	public void testGreedySum() {
		BinaryTree bt = new BinaryTree();

		bt.add(17);
		assertEquals(17, bt.greedySum());

		bt.add(100);
		assertEquals(117, bt.greedySum());

		bt.add(3);
		assertEquals(117, bt.greedySum());

		bt.add(100);
		assertEquals(217, bt.greedySum());

		bt.add(200);
		assertEquals(317, bt.greedySum());

		bt.add(1000);
		assertEquals(317, bt.greedySum());
	}

	@Test
	public void testMaxSum() {
		BinaryTree bt = new BinaryTree();

		bt.add(17);
		assertEquals(17, bt.maxSum());

		bt.add(100);
		assertEquals(117, bt.maxSum());

		bt.add(3);
		assertEquals(117, bt.maxSum());

		bt.add(100);
		assertEquals(217, bt.maxSum());

		bt.add(200);
		assertEquals(317, bt.maxSum());

		bt.add(1000);
		assertEquals(1020, bt.maxSum());
	}

	@Test
	public void testPreOrderTraversalPath() {
		BinaryTree bt = new BinaryTree();
		int[] data = { 4, 5, 6, 7, 8, 9, 10 };
		int[] result = { 4, 5, 7, 8, 6, 9, 10};

		for (int n : data) {
			bt.add(n);
		}

		Queue<Integer> q = bt.preOrderTraversalPath();
		for (Integer n : result) {
			assertEquals(n, q.remove());
		}
	}

	@Test
	public void testLevelOrderTraversalPath() {
		BinaryTree bt = new BinaryTree();
		int[] data = { 4, 5, 6, 7, 8, 9, 10 };

		for (int n : data) {
			bt.add(n);
		}

		Queue<Integer> q = bt.levelOrderTraversalPath();
		for (Integer n : data) {
			assertEquals(n, q.remove());
		}
	}

}