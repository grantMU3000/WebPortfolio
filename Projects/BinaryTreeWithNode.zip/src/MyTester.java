public class MyTester {

	public static void main(String[] args) {
		BinaryTree bt = new BinaryTree();
		
		bt.add(3);
		bt.add(7);
		bt.add(6);
		
		// The following can be solved by watching the videos
		System.out.println("3? " + bt.nodeCount()); // 3
		System.out.println("7? " + bt.max()); // 7
		System.out.println("2? " + bt.leafCount()); // 2
		System.out.println("{7,6} or {6, 7}? "  + bt.allLeaves()); // {7, 6} or {6, 7}
		System.out.println("{10, 9} or {9, 10}? "  + bt.allSums()); // {10, 9} or {9, 10}
		
		System.out.println("16? " + bt.sum());
		
		// bt.add(100);
		System.out.println("116? " + bt.sum());
		
		System.out.println("\n --- Testing allPaths -- \n");
		BinaryTree aP = new BinaryTree();
		
		aP.add(5);
		aP.add(10);
		aP.add(20); 
		aP.add(30); 
		aP.add(90);
		aP.add(70);
		aP.add(50);
		
		System.out.println("{\"5 10 30\", \"5 10 40\", \"5 20 50\"}? " + aP.allPaths());
		
		System.out.println("95? " + aP.greedySum());
		
		System.out.println("105? " + aP.maxSum());
		bt.postOrderTraversal(); // 7 6 3 
		
		System.out.print("30 90 10 70 50 20 5? ");
		aP.postOrderTraversal();
		
		System.out.print("3 7 6? ");
        bt.preOrderTraversal();
        
        System.out.print("5 10 30 90 20 70 50? ");
        aP.preOrderTraversal();
	
	}

}
