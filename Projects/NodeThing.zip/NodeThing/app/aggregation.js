const { MongoClient, ServerApiVersion } = require('mongodb');
const uri = "mongodb+srv://fabusooo:letstalkhoops@hoopcyclopedia.kpm43ud.mongodb.net/hoopcyclopedia?retryWrites=true&w=majority&appName=hoopcyclopedia";

const fs = require('fs'); // Importing the File System module

async function findLeaders(stat, minMinutesPerGame, gamesPlayed) {
    const client = createMongoClient();

    try {
        await client.connect();
        const database = client.db('hoopcyclopedia');
        const collection = database.collection('players');

        minMinutesPerGame = parseInt(minMinutesPerGame);
        gamesPlayed = parseInt(gamesPlayed);
  
      // Constructs the aggregation pipeline based on input parameters
        const pipeline = [
        { 
          $match: { 
            "Stats.Games Played": { $gte: gamesPlayed },
            // "Age": { $lte: ageFilter},
            "Stats.Minutes Per Game": { $gte: minMinutesPerGame }
          } 
        },
        { 
          $project: { 
            "_id": 0, // Excludes _id field
            "Player_ID": 1,
            "Name": 1, // Includes Name field
            "Abbrev": 1, // Includes Team field
            "Age": 1, // Includes Age
            "Stats.Games Played": 1, // Includes Games Played
            "Stats.Minutes Per Game": 1, // Includes Minutes per Game
            [`Stats.${stat}`]: 1, // Includes the chosen stat field from Basic Stats
          }
        },
        { 
          $sort: {
            [ `Stats.${stat}` ]: -1, // Sorts by the chosen field from Basic Stats in descending order
          }
        }
        ];
  
        // Executes the aggregation pipeline and returns the result
        const result = await collection.aggregate(pipeline).toArray();

        // Writes the result to a JSON file
        fs.writeFileSync('result.json', JSON.stringify(result, null, 2));

        return result;
    } finally {
      await client.close();
    }
  }
  
  module.exports = { findLeaders };

//async function playerSearch(player_name) { 
   // const client = createMongoClient();
   // try {
       // await client.connect();
        //const database = 10;

       // const result = await collection.aggregate(pipeline).toArray();
      //  return 
   // } finally {
     //   await client.close();
   // }
//}

// Don't touch 
function createMongoClient() {
    const client = new MongoClient(uri, {
        useNewUrlParser: true,
        useUnifiedTopology: true,
        serverApi: {
          version: ServerApiVersion.v1,
          strict: true,
          deprecationErrors: true,
        }
      });

    return client;
}

// { $match: { "Stats.Games Played": { $gte: gamesPlayed }, "Summaries.Age": { $gte: ageFilter }, "Stats.Minutes Per Game": { $gte: minMinutesPerGame }} }, { $project: {  "_id": 0,  "Player_ID": 1, "Name": 1, "Team": 1, [`Stats.${stat}`]: 1, [`Advanced_Stats.${stat}`]: 1  } }, { $sort: {  [ `Stats.${stat}` ]: -1,  [ `Advanced_Stats.${stat}` ]: -1 }}