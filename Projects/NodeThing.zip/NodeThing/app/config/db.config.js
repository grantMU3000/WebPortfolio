module.exports = {
    url: "mongodb+srv://zeltnecj:7g5y9GpQehx6zfxz@hoopsyclopedia.11wyrji.mongodb.net/Hoopsyclopedia?retryWrites=true&w=majority&appName=Hoopsyclopedia"
    // url: "mongodb+srv://fabusooo:letstalkhoops@hoopcyclopedia.kpm43ud.mongodb.net/hoopcyclopedia?retryWrites=true&w=majority&appName=hoopcyclopedia"
};