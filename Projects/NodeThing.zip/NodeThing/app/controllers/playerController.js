const db = require("../models");
const Player = db.Player;

exports.findAll = (req, res) => {
    // console.log("headers: ", req.headers.connection);                 //  TODO: Block Apple Users
    const player_ID = req.query.player_ID;
    var condition = player_ID ? { Player_ID: { $regex: new RegExp(player_ID), $options: "i" } } : {};
    stat = "Points Per Game";
    gamesPlayed = 40;
    years = 20;
    minutes = 5;
    // condition = { "Stats.Games Played": { $gte: 40 }, "Summaries.Age": { $gte: 20 + "Years"}, "Advanced_Stats.Minutes Per Game": { $gte: 5 } }, { $project: {  "_id": 0,  "Player_ID": 1, "Name": 1, "Team": 1, [`Stats.${stat}`]: 1, [`Advanced_Stats.${stat}`]: 1  } }, { $sort: {  [`Stats.${stat}`]: -1,  [`Advanced_Stats.${stat}`]: -1 }}
    // condition = { "Stats.Games Played": { $gt: 80} };
    console.log(condition);

    Player.find(condition).then(data => {
        // console.log({data});
        res.send({data});
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some Error Occurred while retrieving Players."
        });
    });
};

exports.findPlayer = (req, res) => {
    var id = parseInt(req.params.player_ID);
    var condition = { Player_ID: id };

    Player.findOne(condition).then(data => {
        if (!data)
            res.status(404).send({ message: "Player Not Found with ID: " + id });
        else res.send({data});
    }).catch(err => {
        res.status(500).send({ message: "Error retireving User with id: " + id });
    });
};

exports.findAllStat = (req, res) => {
    const statSort = req.params.stat;
    console.log(statSort);
    const sortObj = { [`Stats.${statSort}`]: -1 };

    Player.find({}).sort(sortObj).then(data => {
        res.send({data});
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some Error Occurred while retrieving Players."
        });
    });
}

exports.randomPlayer = (req, res) => {
    Player.aggregate([{ $sample: { size: 1 } }]).then(data => {
        res.send({data});
    });
};