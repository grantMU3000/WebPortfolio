const db = require("../models");
const User = db.User;

exports.create = (req, res) => {
    if (!req.body.username) {
        res.status(400).send({ message: "Content can not be empty!" });
        return;
    }

    const user = new User({
        username: req.body.username,
        password: req.body.password
    });

    user.save(user).then(data => {
        res.send({data});
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some Error Occurred while creating User."
        });
    });
};

// exports.findAll = (req, res) => {
//     // console.log("headers: ", req.headers.connection);                 //  TODO: Block Apple Users
//     const username = req.query.username;
//     var condition = username ? { username: { $regex: new RegExp(username), $options: "i" } } : {};

//     User.find(condition).then(data => {
//         console.log({data});
//         res.send({data});
//     }).catch(err => {
//         res.status(500).send({
//             message: err.message || "Some Error Occurred while retrieving Users."
//         });
//     });
// };

exports.findUsername = (req, res) => {
    const name = req.params.username;

    User.findOne({ username: name }).then(data => {
        if (!data)
            res.status(404).send({ message: "User Not Found with Username: " + name });
        else res.send({data});
    }).catch(err => {
        res.status(500).send({ message: "Error retireving User with username: " + name });
    });
};