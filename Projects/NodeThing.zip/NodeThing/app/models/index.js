const dbConfig = require("../config/db.config.js");

const mongoose = require("mongoose");
mongoose.Promise = global.Promise;

const db = {};
db.mongoose = mongoose;
db.url = dbConfig.url;
db.Player = require("./playerModel.js")(mongoose);
db.User = require("./userModel.js")(mongoose);

module.exports = db;