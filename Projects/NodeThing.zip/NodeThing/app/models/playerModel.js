module.exports = mongoose => {
    var schema = mongoose.Schema({}, { strict: false });

    schema.method("toJSON", function() {
        const { __v, _id, ...object} = this.toObject();
        object.id = _id;
        return object;
    });

    const Player = mongoose.model("Player", schema, "players");
    return Player;
}