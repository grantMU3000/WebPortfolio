const bcrypt = require("bcrypt");
const SALT = 10;


module.exports = mongoose => {
    var schema = mongoose.Schema({}, { strict: false });

    schema.method("toJSON", function() {                 //  Needed to utilize playerID as db id instead of generated _id
        const { __v, _id, ...object} = this.toObject();
        object.id = _id;
        return object;
    });

    schema.pre("save", function(next) {
        var user = this;
        if (!user.isModified("password")) return next();
        bcrypt.genSalt(SALT, function(err, salt) {
            if (err) return next(err);
            bcrypt.hash(user.password, salt, function(err, hash) {
                if (err) return next(err);
                user.password = hash;
                next();
            });
        });
    });

    schema.methods.comparePassword = function(candidatePassword, cb) {
        bcrypt.compare(candidatePassword, this.password, function(err, isMatch) {
            if (err) return cb(err);
            cb(null, isMatch);
        });
    };

    const User = mongoose.model("User", schema, "users");
    return User;
}