module.exports = app => {
    const players = require("../controllers/playerController.js");
    var router = require("express").Router();

    router.get("/", players.findAll);
    router.get("/:player_ID", players.findPlayer);
    router.get("/stat/:stat", players.findAllStat);
    router.get("/random/1", players.randomPlayer);

    app.use("/api/players", router);
};