module.exports = app => {
    const users = require("../controllers/userController.js");
    var router = require("express").Router();

    router.post("/", users.create);
    // router.get("/", users.findAll);
    router.get("/:username", users.findUsername);

    app.use("/api/user", router);
};