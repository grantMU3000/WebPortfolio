const express = require("express");
const body_parser = require("body-parser");
const cors = require("cors");

const app = express();
const PORT = 3001;
const db = require("./app/models");

var corsOrigin = {
    origin: "http://localhost:3000"
};

app.use(cors(corsOrigin));
app.use(body_parser.json());
app.use(body_parser.urlencoded({ extended: true }));

db.mongoose.connect(db.url, {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => {
    console.log("Connected to the Hoops Database");
}).catch(err => {
    console.log("Cannot connect to the database", err);
    process.exit();
});

app.get("/", (req, res) => {
    res.json({ message: "Welcome to Hoops" })
});

require("./app/routes/playerroutes")(app);
require("./app/routes/userroutes")(app);
// require("./app/routes/auth.routes")(app);

app.listen(PORT, () => {
    console.log("Server is listening...")
});

const { findLeaders } = require('./app/aggregation');
app.get("/findLeaders", async (req, res) => {
    console.log(req.query);
    try {   //  
        const { stat, minMinutesPerGame, gamesPlayed } = req.query;
        const result = await findLeaders(stat, minMinutesPerGame, gamesPlayed);
        res.json(result);
    } catch (error) {
        console.error("Error finding leaders:", error);
        res.status(500).json({ error: "Internal server error" });
    }
});