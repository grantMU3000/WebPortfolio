import React, { useCallback, useEffect, useState } from "react";
import axios from "axios";
import { Routes, Route, Link, useLocation } from "react-router-dom"
import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";

import Home from "./components/home";
import About from "./components/about";
import PlayerStat from "./components/playerstat";
import SearchPage from "./components/searchresult";
import Login from "./components/login";
import Players from "./components/players";
import ApiStuff from "./components/apistuff";
import Compare from "./components/compare";
import More from "./components/more";
import Statleader from "./components/statleader";
// import { getRandomPlayer } from "./utils/player_service";


function App() {
    const location = useLocation();
    const [player, setPlayer] = useState(203999);
    function update() {
        axios.get(`http://localhost:3001/api/players/random/1`).then((res) => {
            setPlayer(res.data.data[0]);
        });
    }
    useEffect(update, []);

    return (
        <div className = "App">
            <link rel = "stylesheet" href = "/HoopsStyle.css" type = "text/css" />
            <link rel = "stylesheet" href = "/HoopsStyle2.css" type = "text/css" />
            <nav className = "navbar navbar-expand navbar-dark">
                <ul>
                    <li className = "navbar-brand">
                        <Link to = {"/"}>HOOPSYCLOPEDIA</Link>
                    /</li>
                    <li className = "navbar-item">
                        <Link to = {"/home"}>HOME</Link>
                    </li>
                    <li className = "navbar-item">
                        <Link to = {"/about"}>ABOUT</Link>
                    </li>
                    <li className = "navbar-item">
                        <Link onClick = {update} to = {`/playerstat/${player.Player_ID}`}>RANDOM</Link>
                    </li>
                    <li className = "navbar-item">
                        <Link to = {`/statleaders/PointsPerGame`}>STAT LEADERS</Link>
                        <ul className = "dropdown">
                            <li><Link to = {`/statleaders/PointsPerGame`}>POINTS PER GAME</Link></li>
                            <li><Link to = {`/statleaders/AssistsPerGame`}>ASSISTS PER GAME</Link></li>
                            <li><Link to = {`/statleaders/ReboundsPerGame`}>REBOUNDS PER GAME</Link></li>
                            <li><Link to = {`/statleaders/StealsPerGame`}>STEALS PER GAME</Link></li>
                            <li><Link to = {`/statleaders/BlocksPerGame`}>BLOCKS PER GAME</Link></li>
                        </ul>
                    </li>
                    <li className = "navbar-item">
                        <Link to = {"/compare"}>COMPARE PLAYERS</Link>
                    </li>
                    <li className = "navbar-item">
                        <Link to = {"/login"}>LOGIN</Link>
                    </li>
                </ul>
            </nav>
            <div className = "container-fluid mt-3">
                <Routes>
                    <Route path = "/" element = {<Home/>}></Route>
                    <Route path = "home" element = {<Home/>}></Route>
                    <Route path = "about" element = {<About/>}></Route>
                    <Route path = "playerstat/:playerID" element = {<PlayerStat/>}></Route>
                    <Route path = "searchpage" element = {<SearchPage/>}></Route>
                    <Route path = "login" element = {<Login/>}></Route>
                    <Route path = "players" element = {<Players/>}></Route>
                    <Route path = "apistuff" element = {<ApiStuff/>}></Route>
                    <Route path = "compare" element = {<Compare/>}>
                        <Route path = "compare/:name1&:name2" element = {<Compare/>}></Route>
                    </Route>
                    <Route path = "more" element = {<More/>}></Route>
                    <Route path = "statleaders/:stat" element = {<Statleader/>}></Route>
                </Routes>
            </div>
        </div>
    );
}

export default App;
