
export default function About() {
    return (
        <section>
            <div>
                <iframe width = "0" height = "0" src = "https://www.youtube.com/embed/6lFpyDg_jps?autoplay=1" title = "Brooklyn and the Bridge" frameborder = "0" allow = "autoplay; encrypted-media;" referrerPolicy = "strict-origin-when-cross-origin"></iframe>
            </div>
            <div className = "pageTitle">
                <img className = "imgAbout" src = "https://cdn.nba.com/logos/leagues/logo-nba.svg" alt = "NBA Logo" height = "280px"></img>
                <h1 className = "websiteName">Hoopsyclopedia</h1>
            </div>

            <div className = "description">
                <p>Welcome to the Hooopsyclopedia! 
                    if you would like to search for current NBA players, catch up on NBA stat 
                    leaders, or just admire our beautiful website, then you’ve come to the right spot!</p>
                    <br></br>
                <p>This website allows users to search for
                    current NBA players in case they wanted to see what team the player is on as well 
                    as their position. Users can also examine player performance on this website since we provide this year’s statistics for each
                    player. If users are not sure how good a player is relative to others, then they can use the compare player feature for
                    one-to-one comparisons. Not only that, but if users want to see who’s the best of the best at a given category, then they
                    can use the “stat leaders” feature. However, if users just want to see some random stats or players, we provide 
                    “Random NBA Player” and a “Random Stat Leader”  searches.</p>
                    <br></br>
                <p>This project was for a software engineering class in college. We created it taking into account the interests of the group members. 
                    We wanted to create a website that makes it easier for basketball lovers to search for their favorite players and 
                    find out more about them.</p>
            </div>
        </section>
    );
}