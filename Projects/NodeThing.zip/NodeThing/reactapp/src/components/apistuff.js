import axios from "axios";


async function postUser() {
    axios.post(
        "http://localhost:3001/api/user",
        {
            username: "TestUser3",
            password: "a1b2"
        }
    );
}
async function getUsers() {
    try {
        const response = axios.get("http://localhost:3001/api/user");
        return response;
    } catch (error) {
        console.log("ERROR: " + error);
    }
}
async function getUser() {
    let name = "TestUser";
    try {
        const response = axios.get(
            "http://localhost:3001/api/user",
            {
                params: {
                    username: name
                }
            }
        );
        return response;
    } catch (error) {
        console.log("ERROR: " + error);
    }
}

export default function ApiStuff() {
    return (
        <section>
            <br></br><br></br><br></br>
            <input placeholder="Username"></input>
            <input placeholder="Password"></input>
            <button onClick={postUser}>PUSH USER</button>
            <div>
                <button onClick={getUsers}>Get Users</button>
            </div>
        </section>
    )
}