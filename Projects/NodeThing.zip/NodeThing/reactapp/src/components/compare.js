import React, { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import axios from "axios";


export default function Compare() {
    let navigate = useNavigate();
    const [searchParams, setSearchParams] = useSearchParams();

    const [players, setPlayers] = useState([]);
    const [result1, setResult1] = useState([]);
    const [result2, setResult2] = useState([]);
    const [search1, setSearch1] = useState([]);
    const [search2, setSearch2] = useState([]);
    useEffect(() => {
        axios.get("http://localhost:3001/api/players").then((res) => {
            setPlayers(res.data.data);
        });
    }, []);

    const players1 = (event) => {
        const searchInput = document.getElementById("searchbar1").value.toLowerCase();
        if (searchInput.length < 2) {
            return;
        }
    
        let playersList = [];
        let len = players.length;
        for (let i = 0; i < len; i++) {
            if ((players[i].Name.toLowerCase().trim()).includes(searchInput.toLowerCase())) {
                playersList.push(players[i]);
            }
        }
        setSearch1(playersList);
        console.log(playersList)
    }
    const players2 = (event) => {
        const searchInput = document.getElementById("searchbar2").value.toLowerCase();
        if (searchInput.length < 2) {
            return;
        }
    
        let playersList = [];
        let len = players.length;
        for (let i = 0; i < len; i++) {
            if ((players[i].Name.toLowerCase().trim()).includes(searchInput.toLowerCase())) {
                playersList.push(players[i]);
            }
        }
        setSearch2(playersList);
    }
    function tosearch1(person) {
        document.getElementById("searchbar1").value = person.Name;
        setResult1(person);
    }
    //same thing as tosearch1 but with a 2 again
    function tosearch2(person) {
        document.getElementById("searchbar2").value = person.Name;
        setResult2(person);
    }
    const SearchResults1 = search1.map(person => {
        return (
            <li class='element' onClick = {() => tosearch1(person)}> {person.Name} </li>
        )
    });
    const SearchResults2 = search2.map(person => {
        return (
            <li class='element' onClick = {() => tosearch2(person)}> {person.Name} </li>
        )
    });

    function comparePlayers() {
        if (document.getElementById("searchbar1").value == "" || document.getElementById("searchbar2").value == "") {
            return;
        }
        let urlParam = document.getElementById("searchbar1").value +'_'+ document.getElementById("searchbar2").value;
        navigate({pathname: "/compare", search: `?compare=${urlParam}`});
    }


    if (searchParams.size !== 0) {
        console.log(searchParams);
        return (
            <table class="compareStats">
                <thead>
                    <tr>
                        <th id="img1"><img src = {"/Headshots/" + result1.Player_ID + ".png"} alt = {result1.Name}></img></th>
                        <th></th>
                        <th id="img2"><img src = {"/Headshots/" + result2.Player_ID + ".png"} alt = {result2.Name}></img></th>
                    </tr>
                    <tr>
                    <th id="name1">{result1.Name}</th>
                    <th></th>
                    <th id="name2">{result2.Name}</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td id="age1">{result1.Age}</td>
                        <td><b>AGE</b></td>
                        <td id="age2">{result2.Age}</td>
                    </tr>
                    <tr>
                        <td id="ppg1">{result1.Stats['PointsPerGame']}</td>
                        <td><b>PPG</b></td>
                        <td id="ppg2">{result2.Stats['PointsPerGame']}</td>
                    </tr>
                    <tr>
                        <td id="rpg1">{result1.Stats['ReboundsPerGame']}</td>
                        <td><b>RPG</b></td>
                        <td id="rpg2">{result2.Stats['ReboundsPerGame']}</td>
                    </tr>
                    <tr>
                        <td id="apg1">{result1.Stats['AssistsPerGame']}</td>
                        <td><b>APG</b></td>
                        <td id="apg2">{result2.Stats['AssistsPerGame']}</td>
                    </tr>
                    <tr>
                        <td id="spg1">{result1.Stats['StealsPerGame']}</td>
                        <td><b>SPG</b></td>
                        <td id="spg2">{result2.Stats['StealsPerGame']}</td>
                    </tr>
                    <tr>
                        <td id="bpg1">{result1.Stats['BlocksPerGame']}</td>
                        <td><b>BPG</b></td>
                        <td id="bpg2">{result2.Stats['BlocksPerGame']}</td>
                    </tr>
                </tbody>
            </table>
        )
    }

    return (
        <section>
            <div class = "mb-2 text-center">
                <h1 class = "display-3" id = "title">Hoopsyclopedia</h1>
            </div>
                <div class = "mb-2 text-center">
                    <h1 class = "display-8">Compare Players</h1>
                </div>
            <div id = "Title" class = "container-fluid text-center">
                <div class="row">
                    <div class = "col-lg-4">
                        <input id="searchbar1" placeholder="player 1" name="search1" type="text" onKeyUp={players1}></input>
                        <ul id="results1">{SearchResults1}</ul>
                    </div>
                    <div class = "col-lg-4"></div>
                    <div class = "col-lg-4">
                        <input id="searchbar2" placeholder="player 2" name="search2" type="text" onKeyUp={players2}></input>
                        <ul id="results2">{SearchResults2}</ul>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <button type="button" class="btn btn-outline-dark btn-lg" onClick={comparePlayers}>Compare Players</button>
                    </div>
                </div>
            </div>
        </section>
    );
}