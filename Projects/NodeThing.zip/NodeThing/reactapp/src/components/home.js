import { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate, useSearchParams } from "react-router-dom";

function Title() {
    return (
        <div id = "Title" className = "container-fluid row text-center">
            <div className = "col-lg-4">
                <img src = "https://cdn.nba.com/logos/leagues/logo-nba.svg" alt = "LOGO" width = "300" height = "180" style = {{float: "left"}}></img>
            </div>
            <div className = "col-lg-4">
                <h1 className = "websiteName">Hoopsyclopedia</h1>
            </div>
        </div>
    )
}
function Description() {
    return (
        <div id = "description" className = "mb-3 text-center">
            <p className = "lead"> Welcome to the Hoopsyclopedia! </p>
            <p className = "col-lg-4 offset-lg-4"> If you would like to search for current NBA players, catch up on the NBA stat leaders, or just admire our beautiful website, then you've come to the right spot! </p>
            <p> Use one of the options below for more details </p>
        </div>
    )
}
function CustomCarousel() {
    const [players, setPlayers] = useState([]);

    useEffect(() => {
        axios.get(`http://localhost:3001/api/players/1641778`).then((res) => {
            setPlayers(res.data.data);
            // console.log(res.data.data)
        });
    }, []);

    // const playerCards = players.map(person => 
    //     <div id = "carouselPlayerCard1" className = "carousel-item text-center">
    //         <img id = "carouselPlayerImg1" src = {"/Headshots/" + person.Player_ID + ".png"} alt = {person.Name} className = "headshot d-block w-100 offset-sm-2"></img>
    //         <h3 id = "carouselPlayerName1">{person.Name}</h3>
    //         <p id = "carouselTeamName1">{person.Team} &emsp; {person.Points}</p>
    //     </div>
    // );
    return (
        <div id = "homeCarouselHousing" className = "container">
            <div id = "homePlayerCarousel" className = "carousel slide carousel-dark col-lg-6 offset-lg-3">

                <div id = "homeCarouselInner" className = "carousel-inner">
                    
                    {/* <ActiveCarouselCard/>
                    <CarouselCard/>
                    <CarouselCard/>
                    <CarouselCard/> */}
                    {/* {playerCards} */}

                    <div id = "carouselPlayerCard1" className = "active carousel-item text-center">
                        <img id = "carouselPlayerImg1" src = {"/Headshots/" + players.Player_ID + ".png"} alt = {players.Name} className = "headshot d-block w-100 offset-sm-2"></img>
                        <h3 id = "carouselPlayerName1">{players.Name}</h3>
                        <p id = "carouselTeamName1">Team: {players.Team} &emsp; Jersey: {players.Jersey}</p>
                    </div>

                </div>
                
                {/* <button className = "carousel-control-prev" type = "button" data-bs-target = "#homePlayerCarousel" data-bs-slide = "prev" onClick = {carouselShifted('prev')}>
                    <span className = "carousel-control-prev-icon" aria-hidden = "true"></span>
                    <span className = "visuall-hidden">Previous</span>
                </button>
                <button className = "carousel-control-next" type = "button" data-bs-target = "#homePlayerCarousel" data-bs-slide = "next" onClick = {carouselShifted('next')}>
                    <span className = "carousel-control-next-icon" aria-hidden = "true"></span>
                    <span className = "visuall-hidden">Next</span>
                </button> */}
            </div>
        </div>
    )
}

function SearchBar(props) {
    const [ input, setInput ] = useState(props?.value ?? "");
    let navigate = useNavigate();
    function searchForPlayers() {
        navigate({pathname: "/SearchPage", search: `?name=${input}`});
    }

    return (
        <div id = "searchForm" className = "container col-lg-6 offset-lg-3">
                <div className = "input-group mb-2">
                    <input id = "searchBar" type = "text" className = "form-control" aria-label = "playerSearch" value = {input} onInput = {e => setInput(e.target.value)}></input>
                    <button id = "searchPlayerButton" className = "btn btn-primary" type = "button" onClick = {searchForPlayers}>Search</button>
                </div>
        </div>
    )
}
function QuickActions() {
    const [player, setPlayer] = useState([]);

    let navigate = useNavigate();
    async function getRandomPlayerPage() {
        // await axios.get(`http://localhost:3001/api/players/random/1`).then((res) => {
        //     setPlayer(res.data.data[0].Player_ID);
        // });
        // navigate(`/playerstat/${player.Player_ID}`);
        navigate("/playerstat/1641778");
    }

    return (
        <div className = "row offset-md-4 mb-3">
            <div className = "col-md-2">
                <button type = "button" className = "btn btn-secondary" onClick = {getRandomPlayerPage}>Random Player</button>
            </div>
            <div className = "col-md-2">
                <button type = "button" className = "btn btn-secondary">Random Stat</button>
            </div>
            <div className = "col-md-2">
                <button type = "button" className = "btn btn-secondary">Advanced Search</button>
            </div>
        </div>
    )
}

  
export default function Home() {
    return (
        <section>
            <Title />
            <Description />
            <CustomCarousel />
            <SearchBar />
            <QuickActions />
        </section>
    );
}