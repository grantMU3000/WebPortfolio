import { useNavigate } from "react-router-dom";

export default function Login() {           //  TODO: Figure out how to maintain login status - localstorage variable?
    let navigate = useNavigate();
    function SignIn() {
        const userName = document.getElementById("userNameInput").value;
        const passWord = document.getElementById("password").value;
        const passWd = Uint8Array.from(atob(passWord), (m) => m.codePointAt(0));    //  Definitely Encrpyted
        localStorage.setItem(userName, passWd);
        navigate("/");
    }
    return (
        <section className = "form-signin w-50 m-auto">
            <form>
                <h1 className = "h3 mb-3 fw-normal text-center">Sign In</h1>
                <div className = "form-floating mb-1">
                    <input id = "userNameInput" type = "username" className = "form-control" placeholder = "Username"></input>
                    <label htmlFor = "userNameInput">Username</label>
                </div>
                <div className = "form-floating">
                    <input id = "password" type = "password" className = "form-control" placeholder = "Password"></input>
                    <label htmlFor = "password">Password</label>
                </div>
                <button className = "btn btn-primary w-100 my-2 py-2" type = "submit" onClick = {SignIn}>Create Account | Sign In</button>
                <p className = "mt-5 mb-3 text-body-secondary">© 2024</p>
            </form>
        </section>
    );
}