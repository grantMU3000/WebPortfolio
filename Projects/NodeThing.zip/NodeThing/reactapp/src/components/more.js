import React, { useEffect, useState } from "react";
import axios from "axios";
import { useParams } from "react-router-dom"




function MorePage() {
    const params = useParams();
    const [player, setPlayer] = useState([]);
    const [stats, setStats] = useState([]);

    useEffect(() => {
        axios.get(`http://localhost:3001/api/players`).then((res) => {
            setPlayer(res.data.data);
            setStats(res.data.data.Stats);
        });
    }, []);

    function getStatandRoute(stat) {

    }

    return (
        <>
            <div class="website-name">STATS</div>

            <div class="description-container">
            </div>

            <div class="morestats">
                <div class="column">
                    <h2>Basic Stats</h2>
                    <ul>
                        <li><a href="StatLeader.html?search=PointsPerGame">Points per Game</a></li>
                        <li><a href="StatLeader.html?search=AssistsPerGame">Assists per Game</a></li>
                        <li><a href="StatLeader.html?search=ReboundsPerGame">Rebounds per Game</a></li>
                        <li><a href="StatLeader.html?search=StealsPerGame">Steals per Game</a></li>
                        <li><a href="StatLeader.html?search=BlocksPerGame">Blocks per Game</a></li>
                        <li><a href="StatLeader.html?search=FieldGoalPercentage">Field Goal Percentage</a></li>
                        <li><a href="StatLeader.html?search=GamesPlayed">Games Played</a></li>
                        <li><a href="StatLeader.html?search=ThreePointPercentage">Three Point Percentage</a></li>
                        <li><a href="StatLeader.html?search=TurnoversPerGame">Turnovers Per Game</a></li>
                        <li><a href="StatLeader.html?search=FreeThrowPercentage">Free Throw Percentage</a></li>
                    </ul>
                </div>
                <div class="column">
                    <h2>Advanced Stats</h2>
                    <ul>
                        <li><a href="StatLeader.html?search=OffensiveRating">Offensive Rating</a></li>
                        <li><a href="StatLeader.html?search=DefensiveRating">Defensive Rating</a></li>
                        <li><a href="StatLeader.html?search=NetRating">Net Rating</a></li>
                        <li><a href="StatLeader.html?search=UsageRate">Usage Rate</a></li>
                        <li><a href="StatLeader.html?search=AssistPercentage">Assist Percentage</a></li>
                        <li><a href="StatLeader.html?search=AssistRatio">Assist Ratio</a></li>
                        <li><a href="StatLeader.html?search=AssistTurnoverRatio">Assist Turnover Ratio</a></li>
                        <li><a href="StatLeader.html?search=EffectiveFieldGoalPercentage">Effective Field Goal Percentage</a></li>
                        <li><a href="StatLeader.html?search=TrueShootingPercentage">True Shooting Percentage</a></li>
                        <li><a href="StatLeader.html?search=OffensiveReboundPercentage">Offensive Rebound Percentage</a></li>
                        <li><a href="StatLeader.html?search=DefensiveReboundPercentage">Defensive Rebound Percentage</a></li>
                        <li><a href="StatLeader.html?search=ReboundPercentage">Rebound Percentage</a></li>
                        <li><a href="StatLeader.html?search=Pace">Pace</a></li>
                        <li><a href="StatLeader.html?search=TurnoversPerGame">Turnovers Per Game</a></li>
                        <li><a href="StatLeader.html?search=WinRatio">Win Ratio</a></li>
                        <li><a href="StatLeader.html?search=Wins">Wins</a></li>
                        <li><a href="StatLeader.html?search=Losses">Losses</a></li>
                    </ul>
                </div>
            </div>
        </>   
    )
}

export default function More() {
    return (
        <section>
            <MorePage />
        </section>
    );
}