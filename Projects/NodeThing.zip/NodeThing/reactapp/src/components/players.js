import React, { useEffect, useState } from "react";
import axios from "axios";

// let players = require("../api/LeagueLeaders.json");
// players = players.resultSet.rowSet;

export default function Players() {
    // console.log(players);
    const [players, setPlayers] = useState([]);          //  CLIENT TO SERVER CONNECTION - WORKS
    useEffect(() => {
        axios.get("http://localhost:3001/api/players").then((res) => {
            setPlayers(res.data.resultSet.rowSet);
            console.log(res.data.resultSet.rowSet);
        });
    }, []);
    return (
        <section>
            <div>
                {players && players.map((player, id) => (
                    <div>
                        <p>{id} -- {player[0]}</p>
                    </div>
                ))}
            </div>
        </section>
    );
}