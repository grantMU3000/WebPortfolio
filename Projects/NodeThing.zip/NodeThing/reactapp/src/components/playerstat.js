import React, { useEffect, useState } from "react";
import axios from "axios";
import { useParams } from "react-router-dom"

function PlayerBio() {
    const params = useParams();
    let playerID = params.playerID;
    const [player, setPlayer] = useState([]);
    const [stats, setStats] = useState([]);

    useEffect(() => {
        axios.get(`http://localhost:3001/api/players/${playerID}`).then((res) => {
            setPlayer(res.data.data);
            setStats(res.data.data.Stats);
        });
    }, []);

    return (
        <>
            <div id = "bio">
                <table>
                    <tbody>
                        <tr></tr>
                        <tr>
                            <th><div id = "playerImg"><img src = {`/Headshots/${player.Player_ID}.png`} alt = {player.Name} width = "250"></img></div></th>
                            <th>
                                <ul>
                                    <li id = "name">{player.Name}</li>
                                    <li id = "birthday">{player.Birthday}</li>
                                    <li id = "HGTWGT">Height: {player.Height} Weight {player.Weight}</li>
                                    <li id = "Team">Team: {player.Team}</li>
                                    <li id = "POS">Position: {player.Position}</li>
                                </ul>
                            </th>
                        </tr>
                    </tbody>
                </table>
            </div>
            <p className = "StatsTitle">Basic Stats</p>
            <table id = "playerstats">
                <thead>
                    <tr>
                        <td>PPG</td>
                        <td>APG</td>
                        <td>RPG</td>
                        <td>BPG</td>
                        <td>SPG</td>
                        <td>FG%</td>
                        <td>3FG%</td>
                        <td>FT%</td>
                    </tr>
                    <tr>
                        <td id = "PPG">{stats.PointsPerGame}</td>
                        <td id = "APG">{stats.AssistsPerGame}</td>
                        <td id = "RPG">{stats.ReboundsPerGame}</td>
                        <td id = "BPG">{stats.BlocksPerGame}</td>
                        <td id = "SPG">{stats.StealsPerGame}</td>
                        <td id = "FG">{stats.FieldGoalPercentage}</td>
                        <td id = "3FG">{stats.ThreePointPercentage}</td>
                        <td id = "FT">{stats.FreeThrowPercentage}</td>
                    </tr>
                </thead>
            </table>
        </>   
    )
}

export default function PlayerStat() {
    return (
        <section>
            <PlayerBio />
        </section>
    );
}