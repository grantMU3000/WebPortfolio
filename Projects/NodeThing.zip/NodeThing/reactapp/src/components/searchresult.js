import React, { useEffect, useState } from "react";
import axios from "axios";
import { useParams, useSearchParams, useNavigate } from "react-router-dom";
import { getPlayerHeadshot } from "../utils/player_service";


function SearchResultsTable() {

    let navigate = useNavigate();
    function searchResults(playerID) {
        navigate({pathname: "/playerstat", search: `?playerID=${playerID}`});
    }

    // returned from `useParams`
    // const { playerID } = useParams();        //  I believe this is for /:player, not ?:player

    const [searchParams, setSearchParams] = useSearchParams();
    const playerName = searchParams.get("name");

    const [players, setPlayers] = useState([]);                 //  TODO: This becomes Database connection querying
    useEffect(() => {
        axios.get("http://localhost:3001/api/players").then((res) => {
            setPlayers(res.data.data);
            // console.log("RESULT: ", res.data.data);
        });
    }, []);

    let playersList = [];
    let len = players.length;
    for (let i = 0; i < len; i++) {
        if ((players[i].Name.toLowerCase().trim()).includes(playerName.toLowerCase())) {
            playersList.push(players[i]);
        }
    }

    function getURL(playerID) {
        return "/playerstat/" + playerID;
    }
    const playerCards = playersList.map(person => 
        <tr>
            <td className = "playerTile">
                <img src = {"/Headshots/" + person.Player_ID + ".png"} alt = {person.Name}></img>
            </td>
            <td><a href={getURL(person.Player_ID)} className="playerRef">{person.Name}</a></td>
            <td className="position">{person.Position}</td>
            <td className="team">{person.Abbrev}</td>
        </tr>
    );

    return (
        <div>
            <h1 id = "resultsFor">Results for: "{playerName}"</h1>
            <table id = "searchResults">
                <thead>
                    <tr>
                        <th></th>
                        <th>Name</th>
                        <th>Position</th>
                        <th>Team</th>
                    </tr>
                </thead>
                <tbody>
                    <>{playerCards}</>
                </tbody>
            </table>
        </div>
    )
}
  
export default function SearchResults() {
    return (
        <section>
            <SearchResultsTable />
        </section>
    );
}