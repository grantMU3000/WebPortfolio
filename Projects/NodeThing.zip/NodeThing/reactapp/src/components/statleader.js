import React, { useEffect, useState } from "react";
import axios from "axios";
import { useParams } from "react-router-dom"

function Stats() {
    const params = useParams();
    const [players, setPlayers] = useState([]);
    const [stats, setStats] = useState([]);

    useEffect(() => {
        axios.get(`http://localhost:3001/api/players/stat/${params.stat}`).then((res) => {
            setPlayers(res.data.data);
            setStats(res.data.data.Stats);
        });
    }, []);

    function getURL(playerID) {
        return "/playerstat/" + playerID;
    }
    const playerCards = players.map(person => 
        <tr>
            <td className = "playerTile">
                <img src = {"/Headshots/" + person.Player_ID + ".png"} alt = {person.Name} width = "100px"></img>
            </td>
            <td><a href={getURL(person.Player_ID)} className="playerRef">{person.Name}</a></td>
            <td className="stat">{person.Stats[params.stat]}</td>
            <td className="team">{person.Abbrev}</td>
        </tr>
    );

    return (
        <>
            <h1 id="showing">Leaders for: {params.stat}</h1>
            <table id="searchResults">
                <thead>
                    <tr>
                        <th></th>
                        <th>Name</th>
                        <th id = "stat">{params.stat}</th>
                        <th>Team</th>
                    </tr>
                </thead>
                <tbody>
                    <>{playerCards}</>
                </tbody>
            </table>
        </>   
    )
}

export default function Statleader() {
    return (
        <section>
            <Stats />
        </section>
    );
}