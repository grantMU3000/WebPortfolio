import axios from "axios";

const playerData = require("../api/LeagueLeaders.json");
const playerInfo = require("../api/PlayerSummary.json");


class PlayerDataService {
    getRandomPlayer() {
        return playerData.resultSet.rowSet[Math.floor(Math.random(playerData.resultSet.rowSet.length))][0];
    }
    getPlayerData() {
        console.log(playerData);
        return playerData;
        // return http.get(`/LeagueLeaders`);
    }
    getPlayerSummary() {
        axios.get("http://localhost:3001/LeagueLeaders").then((res) => {
            return res.data.resultSet.rowSet;
        });
    }
    findByID(playerID) {
        axios.get(`http://localhost:3001/LeagueLeaders?playerID=${playerID}`).then((res) => {
            return res;
        });
    }
    getPlayerHeadshot(playerID) {
        return 1;
    }
}

export default new PlayerDataService();
export function getRandomPlayer() {
    console.log(playerData.resultSet.rowSet.length);
    return playerData.resultSet.rowSet[Math.floor(Math.random() * playerData.resultSet.rowSet.length)][0];
}



// export async function getJSON(fileName) {
//     try {
//         let file = await fetch(fileName);
//         let text = await file.text();
//         let data = JSON.parse(text);
//         return data;
//     } catch (error) {
//         console.error('Error fetching or parsing JSON:', error);
//         throw error; // Rethrow the error to propagate it further
//     }
// }
// export async function getPlayers() {
//     const data = await getJSON(playerData);
//     return data.resultSet.rowSet;
// }
// export async function getRandomPlayer() {
//     let players = await getPlayers();
//     return players[Math.floor(Math.random() * players.length)];
// }
// export async function getRandomPlayerID() {
//     let players = await getPlayers();
//     return players[Math.floor(Math.random() * players.length)][0];
// }

// export function getPlayerData() {
//     return 200;
// }