#include "Crew.h"
// Implement the Crew member functions here

// A constructor that's used to create a crew member based on user input
Crew::Crew(std::string name, std::string schedule) {
    this->name = name;
    this->schedule = schedule;
}

std::string Crew::getName() {
    return name;
}

std::string Crew::getSchedule() {
    return schedule;
}