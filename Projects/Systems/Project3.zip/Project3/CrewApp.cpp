#include <iostream>
#include <fstream>
#include <string>
#include <set>
#include "./CrewApp.h"

using std::string;

// Implement CrewApp function members here

CrewApp::CrewApp(string crewfileName, string flightfileName) {
    // Sets object's file names
    this->crewfileName = crewfileName;
    this->flightfileName = flightfileName;

    std::ifstream crewFile;  // Makes the crew file from the command line
    crewFile.open(this->crewfileName);
    // While loop to go through the crew file and add them to the vector
    while (!crewFile.eof()) {
        string name;
        string schedule;

        crewFile >> name;
        crewFile >> schedule;

        Crew line(name, schedule);
        crews.push_back(line);
    }

    std::ifstream flightFile;  // Makes the flight file from the command line
    flightFile.open(this->flightfileName);
    // While loop to go through the flight file and add them to the vector
    while (!flightFile.eof()) {
        string from;
        string to;

        flightFile >> from;
        flightFile >> to;

        Flight line(from, to);
        flights.push_back(line);
        uniqueFLocations.insert(from);
        uniqueFLocations.insert(to);
    }
}

// Prints a menu for the user to interact with
void CrewApp::PrintMenu() {
    std::cout << "-----------------------------------" << std::endl;
    std::cout << "Airline Crew Scheduling Application" << std::endl;
    std::cout << "-----------------------------------" << std::endl;
    std::cout << "1 List crew names" << std::endl;
    std::cout << "2 List all flight locations" << std::endl;
    std::cout << "3 List crews for the flight" << std::endl;
    std::cout << "4 List flights for the crew" << std::endl;
    std::cout << "-1 Exit" << std::endl;
    std::cout << "-----------------------------------" << std::endl;
    std::cout << "Enter your choice >> ";
}

// Runs different parts of the app based on the user's input
void CrewApp::ExecuteMenu(int opt) {
    if (opt == -1) {

        std::cout << "Bye!" << std::endl;

    } else if (opt == 1) {
        PrintCrews();  // Prints crews since user chose 1
    } else if (opt == 2) {
        PrintUniqueLocations();  // Prints unique flight locations
    } else if (opt == 3) {
        PrintCrewsForFlight();
    } else if (opt == 4) {
        PrintFlightsForCrew();
    } else {
        std::cout << "The wrong choice!" << std::endl;
    }
}

// Prints all of the crew member's names
void CrewApp::PrintCrews() {
    std::cout << "---- Crew List ----" << std::endl;

    for (int i = 0; i < crews.size(); i++) {
        std::cout << crews.at(i).getName() << std::endl;
    }
    std::cout << std::endl;
}

// Prints the unique flight locations
void CrewApp::PrintUniqueLocations() {
    std::cout << "--- Flight Locations ---" << std::endl;

    // Iterates through the unique flight locations. For loop is an iterator
    // that points at each element, and increases at end of each instance.
    for (std::set<string>::iterator it = uniqueFLocations.begin();
        it != uniqueFLocations.end(); it++) {
        // Prints the element in the set that the iterator points to
        std::cout << *it << std::endl;
    }

    std::cout << std::endl;
}

void CrewApp::PrintCrewsForFlight() {
    PrintUniqueLocations();  // Prints the locations for the user to look at

    bool loop = true;

    // Loops until the user enters a valid flight
    while (loop) {
        

        Flight testFlight = makeFlight();  // Gets user's desired flight
        int index = flightExist(testFlight);  // Index of the given flight

        // If the flight can't be found, this is printed and the loop runs
        // again
        if (index == flights.size()) {
            std::cout << "No flight was found!! Please try again..."
                << std::endl;
        } else {
            crewList(index, testFlight);  // Will print the crewlist
            loop = false;  // Ending the loop
        }
    }
}

void CrewApp::PrintFlightsForCrew() {
    std::cout << "Enter the crew name >> ";
    string name;

    bool loop = true;  // Variable for checking list
    // Runs until the user enters a valid name
    while (loop) {
        std::cin >> name;  // Gets the given name from the user
        name = stringToUpperCase(name);  // Makes name uppercase

        std::cout << "---- Assigned Flights ----" << std::endl;

        int index = checkList(name);  // Looks for index of the name

        // Checks if index fits the list. If not, this is run
        if (index >= crews.size()) {
            std::cout << "No record for " << name << ". Please try again..."
                << std::endl;
        } else {
            crewFlights(name, index);
            loop = false;
        }
    }
}

// This method checks if the user's given flight is in the vector
int CrewApp::flightExist(Flight& given) {

    // Loops through the vector and checks if the given flight matches
    for (int i = 0; i < flights.size(); i++) {
        if (flights.at(i).getFrom() == given.getFrom() &&
            flights.at(i).getTo() == given.getTo()) {
            return i;
        }
    }

    return flights.size();
}

// Prints the crew for a given flight
void CrewApp::crewList(const int ind, Flight& given) {
    std::cout << "---- Crew List ----" << std::endl;
    string schedule;
    int count = 0;
    for (int i = 0; i < crews.size(); i++) {
        schedule = crews.at(i).getSchedule();  // Gets crewmate's schedule
        // Checks if the member is scheduled for the day & prints name.
        if (schedule.at(ind) == '1') {
            std::cout << crews.at(i).getName() << std::endl;
            count++;
        }
    }

    std::cout << count << " crew(s) work(s) on the flight " << given.getFrom()
        << "-" << given.getTo() << std::endl;

}

// Will check if the app contains a crew member with given name
int CrewApp::checkList(const string& name) {
    // Loops through the list until name is found or end is reached
    for (int i = 0; i < crews.size(); i++) {
        if (name == crews.at(i).getName()) {
            return i;
        }
    }

    return crews.size();  // Since the name isn't on the list
}

void CrewApp::crewFlights(const string& name, const int ind) {
    string schedule = crews.at(ind).getSchedule();

    bool feas = true;  // For checking if the flight is feasable
    bool flight = false;  // For seeing if the member has any flights
    string last = "";  // For keeping track of the last flight

    // Loops through the crew member's schedule and prints their flights
    for (int i = 0; i < schedule.length(); i++) {
        if (schedule.at(i) == '1') {
            flight = true;

            string to = flights.at(i).getTo();
            std::cout << flights.at(i).getFrom() << " - " <<
                to << std::endl;
            // Checking if flight is feasable. (If there's a prev. flight
            // Or if prev. flight isn't the same as last, it's not feasable)
            if (last != to && last != "0" && last != "") {
                feas = false;
            }
            last = to;
        } else {
            last = "0";
        }
    }  // End of for loop

    if (!flight) {  // Prints if no flights
        std::cout << "No flight was assigned to " << name << std::endl
            << std::endl;
    } else if (feas) {  // Prints if feasible
        std::cout << "The flight sequence is feasible" << std::endl
            << std::endl;
    } else {  // Prints if no flights
        std::cout << "The flight sequence is NOT feasible" << std::endl
            << std::endl;
    }
}

// Getting the user's to and from to create a Flight object
Flight makeFlight() {
    string from;
    string to;
    std::cout << "FROM >> ";
    std::cin >> from;
    std::cout << "TO >> ";
    std::cin >> to;

    Flight input(stringToUpperCase(from), stringToUpperCase(to));
    return input;
}

// Method to convert strings to uppercase
string stringToUpperCase(const string& line) {
    string res;
    for (int i = 0; i < line.length(); i++) {
        res += toupper(line.at(i));
    }

    return res;
}

