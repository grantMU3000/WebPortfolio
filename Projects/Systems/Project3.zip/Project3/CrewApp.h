#ifndef CREWAPP_H
#define CREWAPP_H
#include <vector>
#include <set>
#include "Crew.h"
#include "Flight.h"
#include <string>

using std::string;
class CrewApp {
 private:
       std::vector<Flight> flights;
        std::vector<Crew> crews;
       std::set<std::string> uniqueFLocations;
        string crewfileName;
        string flightfileName;
        int flightExist(Flight& given);
        void crewList(const int ind, Flight& given);
        int checkList(const string& name);
        void crewFlights(const string& name, const int ind);
 public:
        // CrewApp();
        CrewApp(string crewfileName, string flightfileName);
        void PrintMenu();
        void PrintCrews();
        void PrintFlightsForCrew();
        void PrintCrewsForFlight();
        void PrintUniqueLocations();
        void ExecuteMenu(int opt);

};

Flight makeFlight();
string stringToUpperCase(const string& line);
#endif  // CREWAPP_H_

