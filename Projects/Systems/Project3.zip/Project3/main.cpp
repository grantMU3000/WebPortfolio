// Copyright 2023 Grant Robinson
// Submission 1: Got started by checking the command line arguments for errors.
//               If the amount of arguments was incorrect, an error message
//               appears. After that, I made two input files for crew &
//               flights. Then, I checked to see if they were open, and printed
//               messages if they weren't.
// Submission 2: Made a makefile. It works well for what I have in submission 1.
// Submission 3: Corrected my makefile to work with the stuff that I have
//               implemented. I also added an execute menu method, and it has
//               the exit option and the option for numbers not in the menu
//               executed. I also incorporated a loop in the main method to
//               execute the main method.
// Submission 4: Fixed problems with error statements. Implemented the Crew's
//               constructor for the name and schedule. Also implemented the
//               getName() method for the Crew class. In my CrewApp's
//               constructor that I implement, I get the names for the files
//               and then I go through the crew file and add them to the crew
//               vector. I then implemented my menu option 1. This goes through
//               the vector and prints out all of the names of the crewmates.
//               Finally, edited my makefile so that the crew stuff was
//               included.
// Submission 5: Implemented the Flight's constructor for the from & to. Then,
//               I implemented the getter methods for the class. After that, I
//               incorporated the Flight object into my CrewApp constructor.
//               Added the flights to a vector, and the unique flights to a
//               set. Then, I implemented the flight location printing (opt 2).
//               I did this by using an iterator through the set. Then, I
//               updated the makefile.
// Submission 6: Started implementing the third option. I had to make about 3
//               helper methods. One for making the inputted strings uppercase
//               so that they match the strings in the text file. I had another
//               for making a Flight object from the user's input. To be honest
//               I probably didn't need to do this, but my main print method
//               would be more concise, so I'm rolling with it. My last helper
//               method should check if the Flight object exists within the
//               vector. Right now, the method just checks if the inputted
//               flight information works. I also updated CrewAPP's header file
//               to have non-member functions (Since I added the helpers).
// Submission 7: Made another helper method to print the crew working on a
//               given flight. I also changed my FlightExists method to
//               accomodate this change, and implemented my getSchedule in my
//               Crew class.
// Submission 8: I implemented my crewList method that would print the crew
//               members that are on a given flight. I made the method get a
//               flight parameter so that I can print the flight directly in
//               the crewList method.
// Submission 9: I implemented my flight for crews method. I did this by first
//               getting the user's input and converting it to uppercase. Then,
//               I implemented a method that would loop through the crew vector
//               to check if this name was in the list of members. If not, I
//               prompted the user to enter a new name. I used a loop to make
//               sure they would enter a correct name. Then, for a name in the
//               list, I made a method that would print the flights for the
//               member. This method would keep track of the previous flight
//               to make sure the flight schedule is feasible. Then, the
//               feasable status would be printed at the end of the method.

#include <iostream>
#include <fstream>
#include <string>
#include "./CrewApp.h"

using std::string;
using std::cout;
using std::cin;
using std::endl;

int main(int argc, char* argv[]) {
// Verify Command Line Arguments
// Initialize a CrewApp object using the provided filenames.
// Utilize the relevant methods of the CrewApp object to display the menu.
// Prompt the user to select a menu option and execute it until -1 is entered.

    // Checks for enough arguments
    if (argc != 3) {
        cout << "Error!!! Incorrect program arguments" << endl;
        cout << "Format : applicationName [filenameForCrew] ";
        cout << "[filenameForFlight]" << endl;
        return 1;
    }

    std::ifstream crewFile;  // Makes the crew file from the command line
    crewFile.open(argv[1]);

    // Checks if the crew file can be opened
    if (!crewFile.is_open()) {
        cout << "The filename given for crews was not found!!!" << endl;
        cout << "Program ends with an error." << endl;
        return 1;
    }

    std::ifstream flightFile;  // Makes the flight file from the command line
    flightFile.open(argv[2]);

    // Checks if the flights file can be opened
    if (!flightFile.is_open()) {
        cout << "The filename given for flights was not found!!!" << endl;
        cout << "Program ends with an error." << endl;
        return 1;
    }

    CrewApp app(argv[1], argv[2]);

    bool run = true;  // Variable for running the app
    int userNum;  // Variable for tracking the user's input
    // Will run until the user wants to stop
    while (run) {
        app.PrintMenu();
        cin >> userNum;
        app.ExecuteMenu(userNum);
        // If userNum enters zero, run becaomes false so the loop ends
        if (userNum == -1) {
            run = false;
        } else {
            // User presses enter to continue
            cout << "To continue, press enter...";
            // Lines for ignoring the user's input until they hit enter
            cin.get();
            cin.ignore();
        }  // End of if/else
    }  // End of while loop
    return 0;
}
